const fs = require("fs")


const {
smsg, getGroupAdmins, formatp, tanggal, formatDate, getTime, isUrl, await, sleep, clockString, msToDate, sort, toNumber, enumGetKey, runtime, fetchJson, getBuffer, jsonformat, delay, format, logic, generateProfilePicture, parseMention, getRandom, pickRandom, reSize
} = require("./system/lib/MyFunction")


global.d = new Date()
global.calender = d.toLocaleDateString("id")


global.prefa = ["","!",".",",","/","#"]
global.owner = ["628386881536"]
global.ownMain = "628386881536"
global.NamaOwner = "decode.id"
global.usePairingCode = true // Ubah Ke False Jika Ingin Menggunakan Qr Code
global.filenames = "ZynTzy.js"
global.namabot = "𝑩𝒍𝒆𝒔𝒔 𝟔𝟔𝟔 ⸸"
global.author = "𝑩𝒍𝒆𝒔𝒔 𝐈𝐬 𝐇𝐞𝐫𝐞 ϟ"
global.packname = "𝑩𝒍𝒆𝒔𝒔 𝟔𝟔𝟔 ⸸"
global.yt = "https://youtube.com/@zynnxzoo?si=JOeZjhExwm2QaplI"
global.hiasan = `	◦  `
global.gris = '`'



//API PREMIUM\\
global.APIs = {
	gsz: 'https://api.betabotz.eu.org'
}

global.APIKeys = {
	'https://https://api.betabotz.eu.org': 'GetsuzoZhiro'
}

global.gsz = 'ZynXzo'
global.logic = 'Saya adalah AI yang dirancang untuk membantu mahasiswa dalam pembahasan coding serta pelajaran umum seperti Matematika, Bahasa Indonesia, Bahasa Inggris, Fisika, Kimia, Rekayasa Perangkat Lunak, dan Basis Data dengan penjelasan yang mudah dipahami dan relevan'


global.xchannel = {
	jid: '0@newsletter'
	}


global.country = `62`
global.system = {
gmail: `ZynTzy@gmail.com`,
}


global.nick = {
aaa: "亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ 亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ亴⃝ࣰࣰꪾꪾꪾꪾꪾꪾꪾࣧࣧࣧࣧࣧࣧࣧ𝐙ࣱࣱࣩࣨࣨࣨ࣬࣬͋͋͋͋͌͌ࣼ𝐘࣯࣯࣯࣯࣯࣯࣮࣮ࣼࣷࣷࣷࣷᤨᤨ𝐍⃫⃫⃫⃫⃫⃫ࣵࣴࣴࣴࣴ",
sss: "Hahaha ! You are dead !"
}

global.mess = {
 ingroup: '𝘾𝙖𝙣 𝙊𝙣𝙡𝙮 𝘽𝙚 𝙐𝙨𝙚𝙙 𝙞𝙣 𝙂𝙧𝙤𝙪𝙥',
 admin: '𝘾𝙖𝙣 𝙊𝙣𝙡𝙮 𝘽𝙚 𝙐𝙨𝙚𝙙 𝘽𝙮 𝘼𝙙𝙢𝙞𝙣',
 akses: '𝘾𝙖𝙣 𝙊𝙣𝙡𝙮 𝘽𝙚 𝙐𝙨𝙚𝙙 𝘽𝙮 𝘼𝙠𝙨𝙚𝙨',
 usingsetpp: '𝙎𝙚𝙩𝙥𝙥 𝘾𝙖𝙣 𝙊𝙣𝙡𝙮 𝘽𝙚 𝙐𝙨𝙚𝙙 𝘽𝙮 𝙏𝙝𝙚 𝘼𝙠𝙨𝙚𝙨',
 wait: '𝙒𝙖𝙞𝙩𝙞𝙣𝙜 𝙁𝙤𝙧 𝙋𝙧𝙤𝙘𝙚𝙨𝙨𝙞𝙣𝙜',
 success: 'You are dead !',
 bugrespon: '𝙋𝙧𝙤𝙘𝙚𝙨𝙨'
}


global.autOwn = 'req(62-8S57547ms11).287p'
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
	delete require.cache[file]
	require(file)
})