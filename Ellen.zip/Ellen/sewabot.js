const sewabot = () => { 
	return `
*OPEN JASA SEWA BOT*

Sewa 2 Minggu : 10k
Sewa 3 Minggu : 15k
Sewa 1 Bulan    : 20k

*Payment :*
*_Ovo,Dana,Qris,Pulsa_*

Minat?PC
Wa.me/6282274542640
`
}
exports.sewabot = sewabot